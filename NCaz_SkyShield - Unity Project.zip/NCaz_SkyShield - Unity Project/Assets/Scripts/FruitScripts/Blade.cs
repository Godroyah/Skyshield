﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Blade : MonoBehaviour {

    public bool isCutting = false;

    public float minCuttingVelocity = .01f;

    private Vector2 previousPosition;

    public GameObject bladeTrailPrefab;

    //private GameObject currentBladeTrail;

    private CircleCollider2D circleCollider;

    private Rigidbody2D rb;
    public Camera cam;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        circleCollider = GetComponent<CircleCollider2D>();
    }



    // Update is called once per frame
    void Update ()
    {
        //THIS MUST BE CONVERTED TO TOUCH INPUT ON PHONE
	    if(Input.GetMouseButton(0))
        {
            StartCutting();
        }
        else if (Input.GetMouseButtonUp(0))
        {
            StopCutting();
        }

        if (isCutting)
        {
            UpdateCut();
        }

	}

    void UpdateCut ()
    {
       Vector2 newPosition = cam.ScreenToWorldPoint(Input.mousePosition);
        rb.position = newPosition;

        float velocity = (newPosition - previousPosition).magnitude/Time.deltaTime;

        if(velocity > minCuttingVelocity)
        {
            circleCollider.enabled = true;
        }
        else
        {
            circleCollider.enabled = false;
        }

        previousPosition = newPosition;
        //monkyfart
    }

    void StartCutting ()
    {
        isCutting = true;
        // currentBladeTrail = Instantiate(bladeTrailPrefab, transform);
        bladeTrailPrefab.SetActive(true);
        //previousPosition = cam.ScreenToWorldPoint(Input.mousePosition);
        circleCollider.enabled = false;
    }

    void StopCutting ()
    {
        isCutting = false;
        //currentBladeTrail.transform.SetParent(null);
        //Destroy(currentBladeTrail, 2f);
        bladeTrailPrefab.SetActive(false);
        circleCollider.enabled = false;
    }

}
