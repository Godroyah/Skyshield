﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Targeter : MonoBehaviour
{


    //private CircleCollider2D targCol;
    private Rigidbody2D rb;
    public Camera worldCam;
    public GameObject TargGFX;
    public GameObject MlaserA;
    public GameObject MlaserB;
    public GameObject MlaserG;

    public GameObject SiloAlpha;
    public GameObject SiloBeta;
    public GameObject SiloGamma;

    public GameObject friendlyMissileA;
    public GameObject friendlyMissileB;
    public GameObject friendlyMissileG;

    public GameObject missileSpwnA;
    public GameObject missileSpwnB;
    public GameObject missileSpwnG;
    public GameObject missileTrackA;
    public GameObject missileTrackB;
    public GameObject missileTrackG;

    public int num_of_A_Miss = 20;
    public int num_of_B_Miss = 20;
    public int num_of_G_Miss = 20;

    // Use this for initialization
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        //targCol = GetComponent<CircleCollider2D>();
        //targCol.enabled = false;
    }

    // Update is called once per frame
    void Update()
    {
#if UNITY_STANDALONE

        Vector2 targeterPos = worldCam.ScreenToWorldPoint(Input.mousePosition);
        rb.position = targeterPos;

        if (Input.GetMouseButtonDown(0))
        {
            Vector3 mousePos = Input.mousePosition;
            mousePos.z = 10;

            Vector3 screenPos = worldCam.ScreenToWorldPoint(mousePos);

            RaycastHit2D hit = Physics2D.Raycast(screenPos, Vector2.zero);

            if (hit)
            {
                if (hit.collider.name == "SiloAlpha" && num_of_G_Miss > 0)
                {
                    MlaserA.GetComponent<LineRenderer>().enabled = true;
                    TargGFX.SetActive(true);
                    //if (Input.GetMouseButtonUp(0))
                    //{
                        //Instantiate(missileTrackA, transform.position, transform.rotation);
                      //  Instantiate(friendlyMissileA, missileSpwnA.transform.position, missileSpwnA.transform.rotation);
                    //}
                }
                if (hit.collider.name == "SiloBeta" && num_of_B_Miss > 0)
                {
                    //if (Input.GetMouseButtonUp(0))
                    //{
                        //Instantiate(missileTrackB, transform.position, transform.rotation);
                        //Instantiate(friendlyMissileB, missileSpwnB.transform.position, missileSpwnB.transform.rotation);
                    //}
                    MlaserB.GetComponent<LineRenderer>().enabled = true;
                    TargGFX.SetActive(true);
                }
                if (hit.collider.name == "SiloGamma" && num_of_A_Miss > 0)
                {
                    //if (Input.GetMouseButtonUp(0))
                    //{
                        //Instantiate(missileTrackG, transform.position, transform.rotation);
                      //  Instantiate(friendlyMissileG, missileSpwnG.transform.position, missileSpwnG.transform.rotation);
                    //}
                    MlaserG.GetComponent<LineRenderer>().enabled = true;
                    TargGFX.SetActive(true);
                }
                Debug.Log(hit.collider.name);
            }

        }

        if (Input.GetMouseButtonUp(0) && MlaserA.GetComponent<LineRenderer>().enabled == true)
        {
            //GameObject friendlyMissile = Instantiate(friendlyMissileA, missileSpwnA.transform.position, missileSpwnA.transform.rotation) as GameObject;
            // Instantiate(missileTrackA, this.transform.position, this.transform.rotation);
            Instantiate(friendlyMissileA, missileSpwnA.transform.position, missileSpwnA.transform.rotation);
            num_of_G_Miss -= 1;
            //friendlyMissile.GetComponent<MissileControlsA>().targetPos = transform.position;
            MlaserA.GetComponent<LineRenderer>().enabled = false;
            TargGFX.SetActive(false);
        }

        if (Input.GetMouseButtonUp(0) && MlaserB.GetComponent<LineRenderer>().enabled == true)
        {
            //Instantiate(missileTrackB, this.transform.position, this.transform.rotation);
            Instantiate(friendlyMissileB, missileSpwnB.transform.position, missileSpwnB.transform.rotation);
            num_of_B_Miss -= 1;
            MlaserB.GetComponent<LineRenderer>().enabled = false;
            TargGFX.SetActive(false);
        }
        if (Input.GetMouseButtonUp(0) && MlaserG.GetComponent<LineRenderer>().enabled == true)
        {
            //Instantiate(missileTrackG, this.transform.position, this.transform.rotation);
            Instantiate(friendlyMissileG, missileSpwnG.transform.position, missileSpwnG.transform.rotation);
            num_of_A_Miss -= 1;
            MlaserG.GetComponent<LineRenderer>().enabled = false;
            TargGFX.SetActive(false);
        }


#elif UNITY_IOS || UNITY_ANDROID
        if (Input.touchCount > 0)
        {
            Touch tap = Input.GetTouch(0);
            Vector2 targeterPos = worldCam.ScreenToWorldPoint(tap.position);
            rb.position = targeterPos;

            if (tap.phase == TouchPhase.Stationary /*|| tap.phase == TouchPhase.Moved*/)
            {
                Vector3 tapPos = worldCam.ScreenToWorldPoint(new Vector3(tap.position.x, tap.position.y, 10));

                RaycastHit2D hit = Physics2D.Raycast(tapPos, Vector2.zero);

                if (hit)
                {
                    if (hit.collider.name == "SiloAlpha" && num_of_G_Miss > 0)
                    {
                        MlaserA.GetComponent<LineRenderer>().enabled = true;
                        TargGFX.SetActive(true);
                        //if(Input.GetMouseButtonUp(0))
                        //{
                        //  Instantiate(missileTrackA, transform.position, transform.rotation);
                        //Instantiate(friendlyMissileA, missileSpwnA.transform.position, missileSpwnA.transform.rotation);
                        //}
                    }
                    if (hit.collider.name == "SiloBeta" && num_of_B_Miss > 0)
                    {
                        //if (Input.GetMouseButtonUp(0))
                        //{
                        //  Instantiate(missileTrackB, transform.position, transform.rotation);
                        //Instantiate(friendlyMissileB, missileSpwnB.transform.position, missileSpwnB.transform.rotation);
                        //}
                        MlaserB.GetComponent<LineRenderer>().enabled = true;
                        TargGFX.SetActive(true);
                    }
                    if (hit.collider.name == "SiloGamma" && num_of_A_Miss > 0)
                    {
                        //if (Input.GetMouseButtonUp(0))
                        //{
                        //  Instantiate(missileTrackG, transform.position, transform.rotation);
                        //Instantiate(friendlyMissileG, missileSpwnG.transform.position, missileSpwnG.transform.rotation);
                        //}
                        MlaserG.GetComponent<LineRenderer>().enabled = true;
                        TargGFX.SetActive(true);
                    }
                    //Debug.Log(hit.collider.name);
                }

            }

            if (tap.phase == TouchPhase.Ended && MlaserA.GetComponent<LineRenderer>().enabled == true /*&& num_of_A_Miss > 0*/)
            {
                //Instantiate(missileTrackA, this.transform.position, this.transform.rotation);
                Instantiate(friendlyMissileA, missileSpwnA.transform.position, missileSpwnA.transform.rotation);
                num_of_G_Miss -= 1;
                MlaserA.GetComponent<LineRenderer>().enabled = false;
                TargGFX.SetActive(false);
            }

            if (tap.phase == TouchPhase.Ended && MlaserB.GetComponent<LineRenderer>().enabled == true /*&& num_of_B_Miss > 0*/)
            {
                //Instantiate(missileTrackB, this.transform.position, this.transform.rotation);
                Instantiate(friendlyMissileB, missileSpwnB.transform.position, missileSpwnB.transform.rotation);
                num_of_B_Miss -= 1;
                MlaserB.GetComponent<LineRenderer>().enabled = false;
                TargGFX.SetActive(false);
            }
            if (tap.phase == TouchPhase.Ended && MlaserG.GetComponent<LineRenderer>().enabled == true /*&& num_of_G_Miss > 0*/)
            {
                //Instantiate(missileTrackG, this.transform.position, this.transform.rotation);
                Instantiate(friendlyMissileG, missileSpwnG.transform.position, missileSpwnG.transform.rotation);
                num_of_A_Miss -= 1;
                MlaserG.GetComponent<LineRenderer>().enabled = false;
                TargGFX.SetActive(false);
            }
        }
#endif
    }
}


        

   // private void OnTriggerEnter2D (Collider2D other)
    //{
           // if (other.tag == "SiloAlpha")
           // {
               
                  //  MlaserA.GetComponent<LineRenderer>().enabled = true;
               //     TargGFX.SetActive(true);
                
          //  }
          //  else if (other.tag == "SiloBeta")
            //{
               
          //          MlaserB.GetComponent<LineRenderer>().enabled = true;
           //         TargGFX.SetActive(true);
                
         //   }
          //  else if (other.tag == "SiloGamma")
          //  {
               
            //        MlaserG.GetComponent<LineRenderer>().enabled = true;
          //          TargGFX.SetActive(true);
                
           // }
       // }
//}
