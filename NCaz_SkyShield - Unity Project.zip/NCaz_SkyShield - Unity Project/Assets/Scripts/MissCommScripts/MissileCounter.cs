﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MissileCounter : MonoBehaviour {

    public GameObject AMissCount;
    public GameObject BMissCount;
    public GameObject GMissCount;
    Text aMCount;
    Text bMCount;
    Text gMCount;

    public GameObject targeter;
    Targeter myTargeterScript;

    // Use this for initialization
    void Start () 
    {
        aMCount = GetComponent<Text>();
        bMCount = GetComponent<Text>();
        gMCount = GetComponent<Text>();
        myTargeterScript = targeter.GetComponent<Targeter>();
	}
	
	// Update is called once per frame
	void Update () 
    {
        if(this.gameObject == AMissCount)
        {
            aMCount.text = "Gamma: " + myTargeterScript.num_of_G_Miss;
        }
        else if(this.gameObject == BMissCount)
        {
            bMCount.text = "Beta: " + myTargeterScript.num_of_B_Miss;
        }
        else if(this.gameObject == GMissCount)
        {
            gMCount.text = "Alpha: " + myTargeterScript.num_of_A_Miss;
        }
	}
}
