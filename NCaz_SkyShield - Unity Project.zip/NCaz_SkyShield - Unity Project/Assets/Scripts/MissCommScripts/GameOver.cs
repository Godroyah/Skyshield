﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameOver : MonoBehaviour {

    public GameObject bombScore;
    ScoreBombs myBombscoreScript;

    Text finalScore;
    Text scoreText;

	// Use this for initialization
	void Start () 
    {
        myBombscoreScript = bombScore.GetComponent<ScoreBombs>();
        finalScore = GetComponent<Text>();
        bombScore.GetComponent<Text>().enabled = false;
        
        finalScore.text = "Game Over!\nYour time was: \n" + myBombscoreScript.TimeScore.ToString("f1") + 
            "\n\nRestarting!";
    }
	
	// Update is called once per frame
	void Update () 
    {

	}
}
