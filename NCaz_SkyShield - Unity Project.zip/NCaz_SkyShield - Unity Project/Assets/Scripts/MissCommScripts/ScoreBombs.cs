﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreBombs : MonoBehaviour {

    //public GameObject cityAlpha;
    //public GameObject cityBeta;
    //public GameObject cityGamma;

    public float TimeScore = 0;
    public float reset;
    Text score;
    GameObject bomb;

	// Use this for initialization
	void Start ()
    {
        score = GetComponent<Text>();
        bomb = GameObject.FindGameObjectWithTag("Bomb");
	}
	
	// Update is called once per frame
	void Update () 
    {
        //if (cityAlpha != null || cityBeta != null
        // || cityGamma != null)
        //{
        TimeScore = Time.timeSinceLevelLoad;
        //}

        score.text = "Time Score: " + TimeScore.ToString("f1");
	}

    //public void IncrementBombsDestroyed()
    //{
     //   bombsDestroyed++;
    //}
}
