﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CitySpawn : MonoBehaviour {

    public GameObject cityAlpha;
    public GameObject cityBeta;
    public GameObject cityGamma;

    private Vector3 alphaSpawn = new Vector3(-3, -3, 0);
    private Vector3 betaSpawn = new Vector3(0, -3, 0);
    private Vector3 gammaSpawn = new Vector3(6, -3, 0);

    // Use this for initialization
    void Start () 
    {
        Instantiate(cityAlpha, alphaSpawn, transform.rotation);
        Instantiate(cityBeta, betaSpawn, transform.rotation);
        Instantiate(cityGamma, gammaSpawn, transform.rotation);

    }
	
	// Update is called once per frame
	void Update () {
		
	}
}
