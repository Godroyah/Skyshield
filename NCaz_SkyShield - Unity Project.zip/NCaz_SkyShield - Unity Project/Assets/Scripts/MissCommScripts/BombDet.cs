﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BombDet : MonoBehaviour {

    public float delayDestroy;

    // Use this for initialization
    void Start () 
    {

        Destroy(gameObject, delayDestroy);

    }
	
	// Update is called once per frame
	void Update () {
		
	}
}
