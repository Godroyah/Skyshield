﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour {

    public GameObject cityAlpha;
    public GameObject cityBeta;
    public GameObject cityGamma;
    public GameObject gameOver;

    //public GameObject bomb;
    //public BSpawnCont mybspawnScript;

	// Use this for initialization
	void Start () 
    {
      //  mybspawnScript = bomb.GetComponent<BSpawnCont>();
	}
	
	// Update is called once per frame
	void Update () 
    {
        if(cityAlpha == null && cityBeta == null
           && cityGamma == null)
        {
            gameOver.SetActive(true);
            StartCoroutine("Restart");
        }
	}
    IEnumerator Restart()
    {
        yield return new WaitForSeconds(8.0f);
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}
