﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CityDisable : MonoBehaviour {

    public GameObject cityAlpha;
    public GameObject cityBeta;
    public GameObject cityGamma;

    public GameObject bomb;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () 
    {
        if (this.gameObject == cityAlpha)
            if (cityAlpha.transform.position == bomb.transform.position)
            {
                cityAlpha.SetActive(false);
            }
        if (this.gameObject == cityBeta)
            if (cityBeta.transform.position == bomb.transform.position)
            {
                cityBeta.SetActive(false);
            }
        if (this.gameObject == cityGamma)
            if (cityGamma.transform.position == bomb.transform.position)
            {
                cityGamma.SetActive(false);
            }
    }
}
