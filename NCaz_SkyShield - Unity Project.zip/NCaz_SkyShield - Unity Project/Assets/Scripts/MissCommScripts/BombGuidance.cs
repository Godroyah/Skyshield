﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BombGuidance : MonoBehaviour {

    //public GameObject cityAlpha;
    //public GameObject cityBeta;
    //public GameObject cityGamma;
    //private Transform[] cities = new Transform[3];
    public float bombSpeed;
    //GameObject bombScore; 
    //ScoreBombs myBombscoreScript;
    public GameObject bombExplosion;
    //public float life = 100.0f;
    public Vector3 targetPos;
    private Vector3 startPos;

    // Use this for initialization

    void Start()
    {

        //cityAlpha = GameObject.Find("CityAlpha");
        //cityBeta = GameObject.Find("CityBeta");
        //cityGamma = GameObject.Find("CityGamma");

        //int cityIndex = Random.Range(0, cities.Length);
        //cities[0] = cityAlpha.transform;
        //cities[1] = cityBeta.transform;
        //cities[2] = cityGamma.transform;
        //Transform targetCities = cities[cityIndex];
        // GameObject bombScore = GameObject.FindGameObjectWithTag("BombScore");
        // myBombscoreScript = bombScore.GetComponent<ScoreBombs>();
        startPos = transform.position;

        GameObject[] cities = GameObject.FindGameObjectsWithTag("City");
        if (cities.Length > 0)
        {

            int cityIndex = Random.Range(0, cities.Length);
            targetPos = cities[cityIndex].transform.position;


            StartCoroutine("BombTrack");

        }
        else
        {
            Destroy(gameObject);
        }
       // StartCoroutine("DestroySelf");
        //Destroy(gameObject, life);
        //if (targetCities = cities[0])
        //{
        //    StartCoroutine("AlphaBombTrack");
        //    Debug.Log("Alpha");
        //}
        //if (targetCities = cities[1])
        //{
        //    StartCoroutine("BetaBombTrack");
        //    Debug.Log("Beta");
        //}
        //if (targetCities = cities[2])
        //{
        //    StartCoroutine("GammaBombTrack");
        //    Debug.Log("Gamma");
        //}

    }

    IEnumerator BombTrack()
    {
        while (true)
        {
            transform.position = Vector2.MoveTowards(transform.position, targetPos, bombSpeed * Time.deltaTime);
            yield return null;
            //Debug.Log("Alpha");
        }
    }

    //IEnumerator DestroySelf()
    //{
    //    yield return new WaitForSeconds(2.5f);
    //    if(transform.position == startPos)
    //    {
    //        Destroy(gameObject);
    //    }
    //}

    //IEnumerator AlphaBombTrack()
    //{
    //    while (true)
    //    {
    //        transform.position = Vector2.MoveTowards(transform.position, cityAlpha.transform.position, bombSpeed * Time.deltaTime);
    //        yield return null;
    //        //Debug.Log("Alpha");
    //    }
    //}

    //IEnumerator BetaBombTrack()
    //{
    //    while (true)
    //    {
    //        transform.position = Vector2.MoveTowards(transform.position, cityBeta.transform.position, bombSpeed * Time.deltaTime);
    //        yield return null;
    //        //Debug.Log("Beta");
    //    }
    //}

    //IEnumerator GammaBombTrack()
    //{
    //    while (true)
    //    {
    //        transform.position = Vector2.MoveTowards(transform.position, cityGamma.transform.position, bombSpeed * Time.deltaTime);
    //        yield return null;
    //        //Debug.Log("Gamma");
    //    }
    //}

    // Update is called once per frame
    void Update ()
    {
        if(transform.position == targetPos)
        {
            Instantiate(bombExplosion, transform.position, transform.rotation);
            Destroy(gameObject);
        }
            

        //Debug.Log(Time.time);
        //transform.position = Vector2.MoveTowards(transform.position, targetCities.position, bombSpeed * Time.deltaTime);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if(other.tag == "City")
        {
            Instantiate(bombExplosion, transform.position, transform.rotation);
            Destroy(other.gameObject);
            Destroy(gameObject);
        }
        else if(other.tag == "Blast")
        {
            Instantiate(bombExplosion, transform.position, transform.rotation);
            //myBombscoreScript.bombsDestroyed++;
            Destroy(gameObject);
        }
        else if(other.tag == "BombDet")
        {
            Instantiate(bombExplosion, transform.position, transform.rotation);
            Destroy(gameObject);
        }
    }
}
