﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MissileControls : MonoBehaviour
{

    //public Transform MissileTrackerA;
    Camera worldCam;
    public GameObject blastSphere;
    public float missileSpeed;
    private Vector3 targeterPos;




    // Use this for initialization
    void Start()
    {
#if UNITY_STANDALONE
        worldCam = Camera.main;
        targeterPos = worldCam.ScreenToWorldPoint(Input.mousePosition);

#elif UNITY_IOS
        if (Input.touchCount > 0)
        {
            Touch tap = Input.GetTouch(0);
            worldCam = Camera.main;
            targeterPos = worldCam.ScreenToWorldPoint(tap.position);
        }
#endif

    }

    // Update is called once per frame
    void Update()
    {
#if UNITY_STANDALONE

        transform.position = Vector2.MoveTowards(transform.position,
        targeterPos, missileSpeed * Time.deltaTime);
        if (transform.position.x == targeterPos.x && transform.position.y == targeterPos.y)
        {
            //Destroy(MissileTrackerA);
            Instantiate(blastSphere, transform.position, transform.rotation);
            Destroy(gameObject);
        }

#elif UNITY_IOS
        transform.position = Vector2.MoveTowards(transform.position, 
        targeterPos, missileSpeed * Time.deltaTime);
        if(transform.position.x == targeterPos.x && transform.position.y == targeterPos.y)
        {
            //Destroy(MissileTrackerA);
            Instantiate(blastSphere, transform.position, transform.rotation);
            Destroy(gameObject);
        }
#endif
    }
}
