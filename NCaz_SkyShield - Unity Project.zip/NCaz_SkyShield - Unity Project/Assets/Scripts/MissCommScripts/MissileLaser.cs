﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MissileLaser : MonoBehaviour {

    
    private LineRenderer missileLaserAlpha;
    public Transform targeter;
    public Transform silo;

	// Use this for initialization
	void Start ()
    {
        missileLaserAlpha = GetComponent<LineRenderer>();
        missileLaserAlpha.enabled = false;
	}

    // Update is called once per frame
    void Update()
    {
        missileLaserAlpha.SetPosition(0, targeter.position);
        missileLaserAlpha.SetPosition(1, silo.position);
    }

}
